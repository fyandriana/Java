/**
 * 
 */
/**
 * 
 */
module Automobile {
	requires java.desktop;
}