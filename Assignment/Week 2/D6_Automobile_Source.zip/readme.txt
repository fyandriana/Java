Java Version: JavaSE-21
javac -d out src/ca/herzing/automobile/*.java
java -cp out ca.herzing.automobile.AutoCustomerGui