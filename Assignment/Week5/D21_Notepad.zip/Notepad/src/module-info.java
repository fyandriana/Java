/**
 * 
 */
/**
 * 
 */
module Notepad {
	requires java.desktop;
}