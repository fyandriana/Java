package ca.herzing.automobile;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.ActionEvent;
// import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;


public class AutoCustomerGui extends JFrame {
    private final JTextField nameField = new JTextField(20);
    private final JComboBox<String> typeBox = new JComboBox<>(new String[]{"Select", "Employee", "Manager"});
    private final JTextField amountField = new JTextField(10);
    private final JTextArea outputArea = new JTextArea(12, 60);
    private final JLabel lblNote = new JLabel(" ");

    private final ArrayList<AutoCustomer> customers = new ArrayList<>();
    
    private static final NumberFormat MONEY = NumberFormat.getCurrencyInstance(Locale.CANADA);
    
    // to change: mysql 8.2
    private final String DB_URL_CONNECTION = "jdbc:mysql://localhost:3306/automobile";
	private final String DB_USERNAME = "root"; // change as needed
	private final String DB_PWD = "";     // change as needed
	
	/** customer
	  * customer_type string
	  * name string
	  * sub_total double
	  * new_total double
	  * 
	  * 
	  * to test create table customers
	  * 
		CREATE TABLE IF NOT EXISTS customers (
		  id BIGINT AUTO_INCREMENT PRIMARY KEY,
		  customer_type VARCHAR(50),
		  name VARCHAR(100),
		  sub_total DOUBLE,
		  new_total DOUBLE
		);
	  
	 */
	
	 private final DefaultTableModel model = new DefaultTableModel(
	    new Object[]{"Type", "Name", "Total", "New Total"}, 0) {
	    @Override public boolean isCellEditable(int r, int c) { return false; }
	    @Override public Class<?> getColumnClass(int columnIndex) {
	        // render numbers right-aligned; others as text
	        return switch (columnIndex) {
	            case 2,3 -> Double.class; // total, new_total
	            default -> Object.class;   // type, name (id type varies by DB)
	        };
	    }
	};
	
	// Renderer that shows currency for all Number columns
	private final DefaultTableCellRenderer currencyRenderer = new DefaultTableCellRenderer() {
      private final java.text.NumberFormat money =
          java.text.NumberFormat.getCurrencyInstance(java.util.Locale.CANADA);
      @Override public void setValue(Object v) {
        setHorizontalAlignment(SwingConstants.RIGHT);
        if (v instanceof Number n) setText(money.format(n.doubleValue()));
        else if (v == null) setText("");
        else setText(v.toString());
      }
    };
	
	private final JTable table = new JTable(model);

	
    public AutoCustomerGui() {
        super("D16 - Automobile Calculation");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout());
        root.setBorder(BorderFactory.createEmptyBorder(8,8, 8, 8)); // window padding
        setContentPane(root);
        
        // Form panel (top)
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6, 6, 6, 6);
        gc.fill = GridBagConstraints.HORIZONTAL;

        // Type
        gc.gridx = 0; gc.gridy = 0; form.add(new JLabel("Customer Type:"), gc);
        gc.gridx = 1; gc.gridy = 0; form.add(typeBox, gc);
        
        // Name
        gc.gridx = 0; gc.gridy = 1; form.add(new JLabel("Customer Name:"), gc);
        gc.gridx = 1; gc.gridy = 1; form.add(nameField, gc);

        // Amount
        gc.gridx = 0; gc.gridy = 2; form.add(new JLabel("Amount (subtotal):"), gc);
        gc.gridx = 1; gc.gridy = 2; form.add(amountField, gc);

        // Note
        // NOTE row (spans 2 columns)
        gc.gridx = 0; gc.gridy = 3; 
        gc.gridwidth = 2; 
        gc.weightx = 1;
        lblNote.setForeground(Color.DARK_GRAY);
        lblNote.setFont(lblNote.getFont().deriveFont(Font.ITALIC, 12f));
        lblNote.setText("** If the customer type is not selected, no discount will be applied");
        form.add(lblNote, gc);
        // reset for later rows
        gc.gridwidth = 1;
       
        
        // Buttons
        JButton calcBtn = new JButton("Calculate");
        calcBtn.addActionListener(this::onCalculate);
        JButton clearBtn = new JButton("Clear");
        clearBtn.addActionListener(this::onClear);

        JButton saveBtn = new JButton("Save to DB");
        saveBtn.addActionListener(this::onSave);

        JButton showBtn = new JButton("Show all");
        showBtn.addActionListener(this::onShow);

        JPanel btnRow = new JPanel();
        btnRow.add(calcBtn);
        btnRow.add(saveBtn);
        btnRow.add(clearBtn);
        btnRow.add(showBtn);

        gc.gridx = 0; gc.gridy = 4; gc.gridwidth = 2; form.add(btnRow, gc);

        // Output area
//        outputArea.setEditable(false);
//        outputArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
//        outputArea.setLineWrap(false); // keep columns aligned
//        outputArea.setMargin(new Insets(8, 10, 8, 10));
        JScrollPane scroller = new JScrollPane(outputArea,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        table.setAutoCreateRowSorter(true);  // click headers to sort
        table.setFillsViewportHeight(true);

        // Optional: nicer default widths
        table.getColumnModel().getColumn(0).setPreferredWidth(80);   // type
        table.getColumnModel().getColumn(1).setPreferredWidth(220);   // Name
        table.getColumnModel().getColumn(2).setPreferredWidth(80);  // Total
        table.getColumnModel().getColumn(3).setPreferredWidth(80);  // New Total

        // apply to both money columns (the whole “row’s” money cells)
        table.getColumnModel().getColumn(2).setCellRenderer(currencyRenderer); // Total
        table.getColumnModel().getColumn(3).setCellRenderer(currencyRenderer); // New Total
        
        // Layout
        setLayout(new BorderLayout(10, 10));
        add(form, BorderLayout.NORTH);
        add(scroller, BorderLayout.CENTER);
        add(new JScrollPane(table), BorderLayout.CENTER);
        
        getRootPane().setDefaultButton(calcBtn);
        pack();
        setLocationRelativeTo(null);

        // Header
        // resetTable();
    }

//    private void resetTable() {
//        String header =
//                AutoCustomer.tableTitle() + System.lineSeparator() +
//                AutoCustomer.tableHeader() + System.lineSeparator() +
//                AutoCustomer.separator("-") + System.lineSeparator();
//        outputArea.setText(header);
//    }

    private void onCalculate(ActionEvent e) {
        String name = nameField.getText().trim();
        String selected = (String) typeBox.getSelectedItem();
        String type = (selected == null || "Select".equals(selected)) ? "" : selected;
        String amountText = amountField.getText().trim();

        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the customer's name.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Amount must be a number (e.g., 123.45).", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (amount < 0) {
            JOptionPane.showMessageDialog(this, "Amount cannot be negative.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        AutoCustomer customer = new AutoCustomer(name, type, amount);
        // Append a single formatted row generated by toString()
        // add customer to the array list
        model.addRow(new Object[]{
        		customer.getCustomerType(), 
        		customer.getName(), 
        		customer.getSubTotal(),
        		customer.getNewTotal()}
        );       

        
        customers.add(customer);
        outputArea.append(customer.toString() + System.lineSeparator());
    }

    private void _clear() {
    	// empty customers array list
    	customers.clear();
    	
    	// clear Jtable
    	model.setRowCount(0);              // clears all rows
    	table.clearSelection();            
    	
    	nameField.setText("");
        amountField.setText("");
        typeBox.setSelectedIndex(0);
        // resetTable();
        nameField.requestFocus();
    }
    
    private void onClear(ActionEvent e) {
        this._clear();
    }
    
    private void onSave(ActionEvent e) {
    	if(customers.isEmpty()) {
    		showError("No Customers Recorded Yet!");
    		return;
    	}
		
		 Connection conn = null;
		 PreparedStatement ps = null;
		 try {
			 conn = DriverManager.getConnection(this.DB_URL_CONNECTION, this.DB_USERNAME, this.DB_PWD);
		     String sql = "INSERT INTO customers (customer_type, name, sub_total, new_total) "
		     				+ "VALUES (?, ?, ?, ?)";
		     ps = conn.prepareStatement(sql);
		
		     // looping customers list
		     for (AutoCustomer customer : customers) {
		         ps.setString(1, customer.getCustomerType());
		         ps.setString(2, customer.getName());
		         ps.setDouble(3,  customer.getSubTotal());
		         ps.setDouble(4,  customer.getNewTotal());
		         ps.executeUpdate();
		     }
		     showError("All customers ("+ customers.size() +") records submitted to database.");

		     customers.clear();
		     
		 } catch (SQLException ex) {
			 showError("Database error: " + ex.getMessage());
		 }
		 finally { //closing all resources
			 try {
		            if (ps != null) ps.close();
		            if (conn != null) conn.close();
		        } catch (SQLException ex) {
		        	showError("Error closing database resources: " + ex.getMessage());
		        }
		 }
    	this._clear();
    }
    
    private void onShow(ActionEvent e) {
    	model.setRowCount(0);
        final String sql = """
            SELECT *
            FROM customers
            ORDER BY id DESC
            """;
        Connection conn = null;
        try  {
        	conn = DriverManager.getConnection(this.DB_URL_CONNECTION, this.DB_USERNAME, this.DB_PWD);
        	Statement st = conn.createStatement();
        	ResultSet rs = st.executeQuery(sql);

        	if(!rs.next()) {
        		showError("No record found!");
        		return;
        	}
            do{
                // Object id        = rs.getObject(1);   // DB may return Integer/Long/BigInteger
                String type      = rs.getString(2);
                String name      = rs.getString(3);

                Double total     = rs.getObject(4) == null ? null : rs.getDouble(4);
                Double newTotal  = rs.getObject(5) == null ? null : rs.getDouble(5);

                model.addRow(new Object[]{type, name, total, newTotal});
            }
            while(rs.next());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Failed to load customers:\n" + ex.getMessage(),
                    "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Invalid Input", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
		try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found.");
        }
        SwingUtilities.invokeLater(() -> new AutoCustomerGui().setVisible(true));
    }
}
