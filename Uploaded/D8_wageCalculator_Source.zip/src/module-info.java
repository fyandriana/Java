/**
 * 
 */
/**
 * 
 */
module WageCalculator {	
	requires java.desktop;
	
}