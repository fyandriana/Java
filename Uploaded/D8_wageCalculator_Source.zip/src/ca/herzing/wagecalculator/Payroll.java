package ca.herzing.wagecalculator;

public interface Payroll {
	void generatePayroll();
}
