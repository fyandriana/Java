Java Version: JavaSE-21
javac -d out src/ca/herzing/wagecalculator/*.java
java -cp out ca.herzing.wagecalculator.WageCalculator